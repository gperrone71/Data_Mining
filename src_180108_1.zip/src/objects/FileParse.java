package objects;

public class FileParse {

	private String strFileName;
	private boolean bTestSet;
	public String getStrFileName() {
		return strFileName;
	}
	public void setStrFileName(String strFileName) {
		this.strFileName = strFileName;
	}
	public boolean isbTestSet() {
		return bTestSet;
	}
	public void setbTestSet(boolean bTestSet) {
		this.bTestSet = bTestSet;
	}
	
	
}
