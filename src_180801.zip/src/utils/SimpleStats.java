package utils;

import java.util.Arrays;

/*
 * Quick & dirty class to calculate stats based on functions taken from StackOverflow
 */

public class SimpleStats 
{
    double[] data;
    int size;   

    public SimpleStats(double[] data) 
    {
        this.data = data;
        size = data.length;
    }   

    public double getMean()
    {
        double sum = 0.0;
        for(double a : data)
            sum += a;
        return sum/size;
    }

    public double getVariance()
    {
        double mean = getMean();
        double temp = 0;
        for(double a :data)
            temp += (a-mean)*(a-mean);
        return temp/(size-1);
    }

    public double getStdDev()
    {
        return Math.sqrt(getVariance());
    }
    
    public double getMax() {
    	double max = Double.MIN_VALUE;
    	
        for(double a : data)
            if (max < a) 
            	max = a;
    	
        return max;
    }
    
    public double getMin() {
    	double min = Double.MAX_VALUE;
    	
        for(double a : data)
            if (min > a) 
            	min = a;
    	
        return min;
    }

    public double getMinIgnoresZero() {
    	double min = Double.MAX_VALUE;
    	
        for(double a : data)
            if ((min > a) && (a != 0)) 
            	min = a;
    	
        return min;
    }
    
    public double median() 
    {
       Arrays.sort(data);

       if (data.length % 2 == 0) 
       {
          return (data[(data.length / 2) - 1] + data[data.length / 2]) / 2.0;
       } 
       return data[data.length / 2];
    }
}